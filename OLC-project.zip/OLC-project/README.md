# Operation Life Change (OLC) — Central Command System

Two independent pieces:

```
OLC-project/
├── frontend/     ← the website itself (HTML/CSS/JS + images). Deploy to GitHub Pages.
└── backend/      ← optional Node server for cross-device accounts. Deploy to Render/Railway/etc.
```

## 1. Frontend — publish to GitHub Pages

`frontend/` is a plain static site: `index.html`, `style.css`, `app.js`,
and an `assets/` folder of images. No build step, no dependencies.

1. Create a new GitHub repo and push the **contents** of `frontend/` to it
   (so `index.html` sits at the repo root).
2. Repo → Settings → Pages → Source: "Deploy from a branch" → `main` / `root`.
3. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.

That's it — it works immediately with no backend, storing each Agent ID's
data in the browser's `localStorage` (multi-account: one device can hold
several Agent IDs, each fully separate).

## 2. Backend — optional, for cross-device sync

By default the site is fully self-contained and offline-capable. If you
want your data to follow you across phone/laptop/etc, deploy `backend/`
(a small Express server) anywhere that runs Node — see `backend/README.md`
for step-by-step Render/Railway instructions — then set:

```js
// frontend/app.js
const API_BASE_URL = 'https://your-deployed-backend-url';
```

and redeploy the frontend. The backend also includes a simple **admin
viewer** (`/admin?key=...`) so you can see every account and its data,
and delete accounts if needed.

GitHub Pages cannot run the backend itself (Pages only serves static
files) — that's why it's a separate deployable piece.

## What's inside

- **14-tier Rank System** with your real badge artwork, click any badge for
  full info (junior officer / senior officer / retired groupings, star
  ranks for General Officers).
- **Daily Goals** with Full / Half / Fail scoring.
- **Trackers**: Water, Screen Time, Sleep, Weight, Height, Exercise, Study.
- **Streak Command Center**, **Medals**, **Side Arm Badges**.
- **The Rule Book** as a real page-flip book of your actual PDF pages.
- **History & Archives** — full daily log, click any day for full detail.
- **Agent ID Card** — 3D flip popup, front/back.
- **Light/Dark mode**, home-screen install support.
- **Multi-account login** (Create ID / Add ID) — no email or password.

## Local testing

Just open `frontend/index.html` directly in a browser — everything works
without a server. To test the backend locally, see `backend/README.md`.
